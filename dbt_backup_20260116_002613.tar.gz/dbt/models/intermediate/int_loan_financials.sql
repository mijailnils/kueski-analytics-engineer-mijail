{{
    config(
        materialized='view',
        tags=['intermediate', 'financials']
    )
}}

-- Combines loan data with repayment revenue to calculate financial margins
-- One row per loan with aggregated financial metrics

with loans as (
    select * from {{ ref('stg_loans') }}
),

repayments as (
    select
        loan_id,
        sum(revenue_total) as total_revenue,
        sum(principal_amount) as total_principal_repaid,
        sum(interest_amount) as total_interest,
        sum(fee_amount) as total_fees,
        sum(penalty_amount) as total_penalties
    from {{ ref('stg_repayments') }}
    group by loan_id
),

customer_acquisition as (
    select * from {{ ref('stg_customer_acquisition') }}
),

joined as (
    select
        l.loan_id,
        l.user_id,
        l.vintage_date,
        l.vintage_month,
        l.vintage_year,
        l.loan_amount,
        l.loan_term,
        l.risk_segment,
        l.state,
        l.is_delinquent,
        l.dpd_bucket,
        
        -- Revenue components
        coalesce(r.total_revenue, 0) as revenue,
        coalesce(r.total_interest, 0) as interest_revenue,
        coalesce(r.total_fees, 0) as fee_revenue,
        coalesce(r.total_penalties, 0) as penalty_revenue,
        
        -- Funding cost (charge-offs)
        l.funding_cost,
        
        -- CAC (customer acquisition cost)
        coalesce(c.total_cac, 0) as cac,
        
        -- Financial margin = Revenue - Funding cost
        {{ calculate_financial_margin(
            'coalesce(r.total_revenue, 0)',
            'l.funding_cost'
        ) }} as financial_margin,
        
        -- COGS = CAC + servicing costs (simplified for now)
        {{ calculate_cogs(
            'coalesce(c.total_cac, 0)',
            '0',  -- servicing_cost (add if available)
            '0'   -- collection_cost (add if available)
        ) }} as cogs,
        
        -- Contribution margin = Revenue - Funding cost - COGS
        {{ calculate_contribution_margin(
            'coalesce(r.total_revenue, 0)',
            'l.funding_cost',
            calculate_cogs('coalesce(c.total_cac, 0)', '0', '0')
        ) }} as contribution_margin,
        
        -- Principal repayment
        coalesce(r.total_principal_repaid, 0) as principal_repaid,
        
        -- Net profit (simplified)
        {{ calculate_contribution_margin(
            'coalesce(r.total_revenue, 0)',
            'l.funding_cost',
            calculate_cogs('coalesce(c.total_cac, 0)', '0', '0')
        ) }} as net_profit
        
    from loans l
    left join repayments r on l.loan_id = r.loan_id
    left join customer_acquisition c on l.user_id = c.user_id
)

select * from joined