{{
    config(
        materialized='table',
        tags=['marts', 'delinquency', 'roll_rates']
    )
}}

-- Roll rate analysis: tracks how loans move between DPD buckets
-- Critical for loss forecasting and collection strategies

with loans as (
    select 
        loan_id,
        user_id,
        vintage_month,
        risk_segment,
        dpd_bucket,
        is_delinquent,
        loan_amount,
        funding_cost
    from {{ ref('stg_loans') }}
),

roll_rate_analysis as (
    select
        vintage_month,
        risk_segment,
        
        -- Current state distribution
        count(distinct case when dpd_bucket = '0_Fully_Paid' then loan_id end) as fully_paid_count,
        count(distinct case when dpd_bucket = '1-30' then loan_id end) as dpd_1_30_count,
        count(distinct case when dpd_bucket = '31-60' then loan_id end) as dpd_31_60_count,
        count(distinct case when dpd_bucket = '61-90' then loan_id end) as dpd_61_90_count,
        count(distinct case when dpd_bucket = '90+' then loan_id end) as dpd_90_plus_count,
        
        -- Roll rates (% moving to next bucket) - requires temporal tracking
        -- This is simplified; ideally track state transitions over time
        
        count(distinct loan_id) as total_loans,
        
        -- Delinquency dynamics
        sum(case when is_delinquent = 1 then 1 else 0 end) / 
            nullif(count(*), 0) as current_delinquency_rate,
            
        -- Loss given default proxy
        sum(funding_cost) / nullif(sum(loan_amount), 0) as loss_rate
        
    from loans
    group by vintage_month, risk_segment
)

select * from roll_rate_analysis
