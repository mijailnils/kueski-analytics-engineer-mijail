{{
    config(
        materialized='view',
        tags=['staging', 'loans']
    )
}}

with source as (
    select * from read_csv_auto('C:/Users/mijai/kueski-analytics-engineer-mijail/data/raw/AE_challenge_loans.csv')
),

cleaned as (
    select
        -- IDs
        loan_id,
        user_id,
        
        -- Dates
        cast(vintage as timestamp) as vintage_timestamp,
        cast(vintage as date) as vintage_date,
        strftime(cast(vintage as date), '%Y-%m') as vintage_month,
        strftime(cast(vintage as date), '%Y') as vintage_year,
        
        -- Loan attributes
        amount as loan_amount,
        term as loan_term,
        risk_segment,
        state,
        
        -- Financial metrics
        charge_off,
        
        -- Funding cost (charge-offs are the actual loss)
        {{ calculate_funding_cost('charge_off') }} as funding_cost,
        
        -- Delinquency tracking
        is_delinquent,
        dpd_bucket,
        
        -- Metadata
        current_timestamp() as loaded_at
        
    from source
)

select * from cleaned